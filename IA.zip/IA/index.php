<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<title>IA Chat - Poe Style App</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<style>
    :root {
        --bg: #0e0e0f;
        --panel: #161616;
        --glass: rgba(255,255,255,0.06);
        --accent: #6b5ef8;
        --text: #eaeaea;
        --muted: #9a9a9a;
    }

    body {
        margin: 0;
        background: var(--bg);
        font-family: Inter, Arial, sans-serif;
        color: var(--text);
        height: 100vh;
        display: flex;
        flex-direction: column;
    }

    /* Header */
    .header {
        padding: 18px 24px;
        font-size: 22px;
        font-weight: 700;
        backdrop-filter: blur(12px);
        background: rgba(0,0,0,0.3);
        border-bottom: 1px solid rgba(255,255,255,0.05);
    }

    /* Main area */
    .content {
        flex: 1;
        overflow-y: auto;
        padding: 30px;
        display: flex;
        flex-direction: column;
        gap: 18px;
    }

    .suggestions {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(260px, 1fr));
        gap: 16px;
        padding-top: 10px;
    }

    .card {
        background: var(--glass);
        border: 1px solid rgba(255,255,255,0.05);
        border-radius: 14px;
        padding: 18px;
        cursor: pointer;
        transition: .2s ease;
    }

    .card:hover {
        transform: translateY(-6px);
        box-shadow: 0 12px 28px rgba(0,0,0,0.4);
    }

    /* Chat Window */
    .chatBox {
        width: 100%;
        max-width: 820px;
        margin: auto;
        background: rgba(255,255,255,0.04);
        border-radius: 16px;
        border: 1px solid rgba(255,255,255,0.06);
        padding: 20px;
        display: none;
        flex-direction: column;
        gap: 14px;
        animation: fadeIn .4s ease;
    }

    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(20px); }
        to   { opacity: 1; transform: translateY(0); }
    }

    .msgUser, .msgIA {
        padding: 12px 16px;
        border-radius: 12px;
        white-space: pre-wrap;
        line-height: 1.4;
        max-width: 90%;
    }

    .msgUser {
        background: var(--accent);
        color: white;
        margin-left: auto;
    }

    .msgIA {
        background: rgba(255,255,255,0.08);
        border: 1px solid rgba(255,255,255,0.05);
    }

    /* Chat input */
    .inputBar {
        padding: 14px;
        display: flex;
        gap: 10px;
        border-top: 1px solid rgba(255,255,255,0.06);
        background: rgba(0,0,0,0.2);
        backdrop-filter: blur(10px);
    }

    .inputBar input {
        flex: 1;
        background: rgba(255,255,255,0.06);
        border: 1px solid rgba(255,255,255,0.1);
        border-radius: 30px;
        padding: 12px 16px;
        outline: none;
        color: white;
        font-size: 16px;
    }

    .inputBar button {
        padding: 12px 18px;
        border-radius: 30px;
        border: 0;
        cursor: pointer;
        background: var(--accent);
        color: white;
        font-weight: bold;
        transition: .2s;
    }

    .inputBar button:hover {
        transform: scale(1.05);
    }
</style>
</head>
<body>

<div class="header">Assistente IA</div>

<div class="content" id="mainArea">

    <h2 style="margin:0;">Sugestões para conversar</h2>

    <div class="suggestions">
        <div class="card" onclick="startChat('Me explique algo novo!')">Me explique algo novo</div>
        <div class="card" onclick="startChat('Me ajude com código')">Me ajude com código</div>
        <div class="card" onclick="startChat('Gere uma ideia criativa')">Gere uma ideia criativa</div>
        <div class="card" onclick="startChat('Faça um resumo para estudo')">Faça um resumo</div>
    </div>

    <div id="chatBox" class="chatBox"></div>

</div>

<!-- Input bar -->
<div class="inputBar">
    <input id="msgInput" placeholder="Digite sua mensagem...">
    <button onclick="sendMessage()">Enviar</button>
</div>


<script>
let history = [];
let chatBox = document.getElementById("chatBox");
let mainArea = document.getElementById("mainArea");

function startChat(initialText) {
    openChat();
    addMessage("user", initialText);
    sendToAI(initialText);
}

function sendMessage() {
    const msg = document.getElementById("msgInput").value.trim();
    if (msg === "") return;

    document.getElementById("msgInput").value = "";

    // Se o chat não estiver aberto → abre automaticamente
    openChat();

    addMessage("user", msg);
    sendToAI(msg);
}

function openChat() {
    if (chatBox.style.display === "none" || chatBox.style.display === "") {
        chatBox.style.display = "flex";
    }
}

function addMessage(role, text) {
    const div = document.createElement("div");
    div.className = role === "user" ? "msgUser" : "msgIA";
    div.textContent = text;

    chatBox.appendChild(div);

    chatBox.scrollTop = chatBox.scrollHeight;

    history.push({ role: role, content: text });
}

// Envia para o IA.php
function sendToAI(message) {

    fetch("ia.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
            prompt: history.map(m => `${m.role.toUpperCase()}: ${m.content}`).join("\n")
        })
    })
    .then(r => r.json())
    .then(data => {
        let reply = data.reply ?? "Erro na IA";
        addMessage("assistant", reply);
    });
}
</script>

</body>
</html>